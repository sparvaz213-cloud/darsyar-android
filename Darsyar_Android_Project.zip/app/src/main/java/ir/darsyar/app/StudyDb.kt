package ir.darsyar.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Subject(val id: Long, val name: String, val importance: Int, val target: Int)
data class StudyTask(val id: Long, val title: String, val subject: String, val done: Boolean)
data class StudyReview(val id: Long, val title: String, val subject: String, val due: Long, val done: Boolean)

class StudyDb(context: Context) : SQLiteOpenHelper(context, "darsyar.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE subjects(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, importance INTEGER NOT NULL, target INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, subject TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, subject TEXT NOT NULL, minutes INTEGER NOT NULL, created INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE reviews(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, subject TEXT NOT NULL, due INTEGER NOT NULL, done INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("INSERT INTO subjects(name,importance,target) VALUES('ریاضی',5,50),('علوم',4,40)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun subjects(): List<Subject> {
        val out = mutableListOf<Subject>()
        readableDatabase.rawQuery("SELECT id,name,importance,target FROM subjects ORDER BY importance DESC", null).use { c ->
            while (c.moveToNext()) out += Subject(c.getLong(0), c.getString(1), c.getInt(2), c.getInt(3))
        }
        return out
    }
    fun addSubject(name: String, importance: Int, target: Int) {
        val v = ContentValues().apply { put("name", name); put("importance", importance); put("target", target) }
        writableDatabase.insert("subjects", null, v)
    }
    fun tasks(): List<StudyTask> {
        val out = mutableListOf<StudyTask>()
        readableDatabase.rawQuery("SELECT id,title,subject,done FROM tasks ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out += StudyTask(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3) == 1)
        }
        return out
    }
    fun addTask(title: String, subject: String) {
        val v = ContentValues().apply { put("title", title); put("subject", subject); put("done", 0) }
        writableDatabase.insert("tasks", null, v)
    }
    fun toggleTask(id: Long, done: Boolean) {
        val v = ContentValues().apply { put("done", if (done) 1 else 0) }
        writableDatabase.update("tasks", v, "id=?", arrayOf(id.toString()))
    }
    fun addSession(subject: String, minutes: Int) {
        val v = ContentValues().apply { put("subject", subject); put("minutes", minutes); put("created", System.currentTimeMillis()) }
        writableDatabase.insert("sessions", null, v)
    }
    fun todayMinutes(): Int {
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0); cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0)
        readableDatabase.rawQuery("SELECT COALESCE(SUM(minutes),0) FROM sessions WHERE created>=?", arrayOf(cal.timeInMillis.toString())).use {
            return if (it.moveToFirst()) it.getInt(0) else 0
        }
    }
    fun addReview(title: String, subject: String) {
        val v = ContentValues().apply {
            put("title", title); put("subject", subject)
            put("due", System.currentTimeMillis() + 24L * 60 * 60 * 1000); put("done", 0)
        }
        writableDatabase.insert("reviews", null, v)
    }
    fun reviews(): List<StudyReview> {
        val out = mutableListOf<StudyReview>()
        readableDatabase.rawQuery("SELECT id,title,subject,due,done FROM reviews WHERE done=0 ORDER BY due", null).use { c ->
            while (c.moveToNext()) out += StudyReview(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3), c.getInt(4) == 1)
        }
        return out
    }
    fun finishReview(id: Long) {
        val v = ContentValues().apply { put("done", 1) }
        writableDatabase.update("reviews", v, "id=?", arrayOf(id.toString()))
    }
}
