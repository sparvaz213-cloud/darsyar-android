package ir.darsyar.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = StudyDb(this)
        setContent { DarsyarApp(db) }
    }
}

private val fa = Locale("fa")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DarsyarApp(db: StudyDb) {
    var page by remember { mutableIntStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }
    val subjects = remember(refresh) { db.subjects() }
    val tasks = remember(refresh) { db.tasks() }
    val reviews = remember(refresh) { db.reviews() }
    val today = remember(refresh) { db.todayMinutes() }
    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF536DFE), secondary = androidx.compose.ui.graphics.Color(0xFF00A884))) {
        CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Scaffold(
                topBar = { TopAppBar(title = { Text("درس‌یار", fontWeight = FontWeight.Bold) }, actions = { Text("نسخه اندروید", modifier = Modifier.padding(end = 16.dp), style = MaterialTheme.typography.labelMedium) }) },
                bottomBar = {
                    NavigationBar {
                        listOf("خانه", "درس‌ها", "وظایف", "تمرکز", "مرور").forEachIndexed { i, label ->
                            val icons = listOf(Icons.Default.Home, Icons.Default.MenuBook, Icons.Default.CheckCircle, Icons.Default.Timer, Icons.Default.Refresh)
                            NavigationBarItem(selected = page == i, onClick = { page = i }, icon = { Icon(icons[i], null) }, label = { Text(label) })
                        }
                    }
                }
            ) { padding ->
                Box(Modifier.padding(padding).fillMaxSize()) {
                    when (page) {
                        0 -> Dashboard(db, today, subjects, tasks, reviews, onNavigate = { page = it })
                        1 -> SubjectsScreen(subjects, onAdd = { n, imp, target -> db.addSubject(n, imp, target); refresh++ })
                        2 -> TasksScreen(tasks, subjects, onAdd = { t, s -> db.addTask(t, s); refresh++ }, onToggle = { id, done -> db.toggleTask(id, done); refresh++ })
                        3 -> FocusScreen(subjects, onComplete = { s, m -> db.addSession(s, m); refresh++ })
                        else -> ReviewsScreen(reviews, subjects, onAdd = { t, s -> db.addReview(t, s); refresh++ }, onDone = { id -> db.finishReview(id); refresh++ })
                    }
                }
            }
        }
    }
}

@Composable
fun Dashboard(db: StudyDb, today: Int, subjects: List<Subject>, tasks: List<StudyTask>, reviews: List<StudyReview>, onNavigate: (Int) -> Unit) {
    val pending = tasks.count { !it.done }
    val goal = 120
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("قدم‌های کوچک، پیشرفت‌های بزرگ ✨", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("برنامه امروزت را هوشمندانه پیش ببر.", color = MaterialTheme.colorScheme.onPrimary)
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Stat("مطالعه امروز", "$today دقیقه")
                        Stat("وظایف باز", "$pending")
                        Stat("مرورها", "${reviews.size}")
                    }
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("هدف مطالعه امروز", fontWeight = FontWeight.Bold)
                        Text("$today / $goal دقیقه")
                    }
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(progress = { (today.toFloat() / goal).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Text(if (today >= goal) "آفرین! به هدف امروز رسیدی 🎉" else "برای رسیدن به هدف، ${goal - today} دقیقه دیگر مطالعه کن.")
                }
            }
        }
        item { Text("برنامه پیشنهادی آفلاین", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        items(subjects.take(4)) { s ->
            Card {
                ListItem(
                    leadingContent = { Icon(Icons.Default.AutoAwesome, tint = MaterialTheme.colorScheme.primary) },
                    headlineContent = { Text(s.name) },
                    supportingContent = { Text("اولویت ${s.importance} از ۵ • پیشنهاد ${s.target} دقیقه مطالعه") }
                )
            }
        }
        item { Text("دسترسی سریع", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onNavigate(3) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Timer, null); Spacer(Modifier.width(4.dp)); Text("تمرکز") }
                OutlinedButton(onClick = { onNavigate(2) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.AddTask, null); Spacer(Modifier.width(4.dp)); Text("وظیفه") }
            }
        }
    }
}

@Composable
fun Stat(title: String, value: String) {
    Column {
        Text(title, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .8f), style = MaterialTheme.typography.labelMedium)
        Text(value, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun SubjectsScreen(subjects: List<Subject>, onAdd: (String, Int, Int) -> Unit) {
    var show by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var importance by remember { mutableIntStateOf(3) }
    var target by remember { mutableStateOf("45") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("درس‌های من", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Button(onClick = { show = true }) { Icon(Icons.Default.Add, null); Text("درس جدید") }
        }
        Spacer(Modifier.height(12.dp))
        if (subjects.isEmpty()) EmptyState("هنوز درسی ثبت نکرده‌ای.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(subjects) { s ->
                Card { ListItem(
                    leadingContent = { Icon(Icons.Default.MenuBook, tint = MaterialTheme.colorScheme.primary) },
                    headlineContent = { Text(s.name, fontWeight = FontWeight.Bold) },
                    supportingContent = { Text("اهمیت ${s.importance} از ۵ • هدف روزانه ${s.target} دقیقه") }
                ) }
            }
        }
    }
    if (show) AlertDialog(
        onDismissRequest = { show = false },
        title = { Text("افزودن درس") },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, label = { Text("نام درس") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(target, { target = it.filter(Char::isDigit) }, label = { Text("هدف روزانه (دقیقه)") }, singleLine = true)
                Text("میزان اهمیت: $importance")
                Slider(value = importance.toFloat(), onValueChange = { importance = it.toInt().coerceIn(1, 5) }, valueRange = 1f..5f, steps = 3)
            }
        },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) { onAdd(name.trim(), importance, target.toIntOrNull() ?: 45); name = ""; show = false } }) { Text("ذخیره") } },
        dismissButton = { TextButton(onClick = { show = false }) { Text("انصراف") } }
    )
}

@Composable
fun TasksScreen(tasks: List<StudyTask>, subjects: List<Subject>, onAdd: (String, String) -> Unit, onToggle: (Long, Boolean) -> Unit) {
    var show by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf(subjects.firstOrNull()?.name ?: "") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("وظایف", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Button(onClick = { show = true }) { Icon(Icons.Default.Add, null); Text("وظیفه جدید") }
        }
        Spacer(Modifier.height(12.dp))
        if (tasks.isEmpty()) EmptyState("وظیفه‌ای ثبت نشده است.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tasks, key = { it.id }) { task ->
                Card { ListItem(
                    leadingContent = { Checkbox(task.done, { onToggle(task.id, it) }) },
                    headlineContent = { Text(task.title) },
                    supportingContent = { Text(task.subject.ifBlank { "بدون درس مرتبط" }) }
                ) }
            }
        }
    }
    if (show) AlertDialog(
        onDismissRequest = { show = false }, title = { Text("وظیفه جدید") },
        text = { Column {
            OutlinedTextField(title, { title = it }, label = { Text("عنوان وظیفه") })
            Spacer(Modifier.height(8.dp))
            if (subjects.isNotEmpty()) {
                Text("درس مرتبط")
                subjects.forEach { s -> Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = subject == s.name, onClick = { subject = s.name })
                    Text(s.name)
                } }
            }
        } },
        confirmButton = { TextButton(onClick = { if (title.isNotBlank()) { onAdd(title.trim(), subject); title = ""; show = false } }) { Text("ثبت") } },
        dismissButton = { TextButton(onClick = { show = false }) { Text("لغو") } }
    )
}

@Composable
fun FocusScreen(subjects: List<Subject>, onComplete: (String, Int) -> Unit) {
    var selected by remember { mutableStateOf(subjects.firstOrNull()?.name ?: "") }
    var mode by remember { mutableIntStateOf(25) }
    var seconds by remember { mutableIntStateOf(25 * 60) }
    var running by remember { mutableStateOf(false) }
    var completed by remember { mutableStateOf(false) }
    LaunchedEffect(running, seconds) {
        if (running && seconds > 0) {
            delay(1000)
            seconds--
            if (seconds == 0) {
                running = false
                completed = true
                if (mode == 25 || mode == 50) onComplete(selected, mode)
            }
        }
    }
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("زمانت را با تمرکز پس بگیر", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(25, 5, 50, 10).forEach { m ->
                FilterChip(selected = mode == m, onClick = { mode = m; seconds = m * 60; running = false; completed = false }, label = { Text("$m دقیقه") })
            }
        }
        Card(shape = RoundedCornerShape(100.dp), modifier = Modifier.size(250.dp)) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("%02d:%02d".format(seconds / 60, seconds % 60), style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold)
                    Text(if (mode <= 10) "استراحت" else "تمرکز", color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        if (subjects.isNotEmpty()) {
            Text("درس جلسه: $selected")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                subjects.forEach { s -> FilterChip(selected = selected == s.name, onClick = { selected = s.name }, label = { Text(s.name) }) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { running = !running }, modifier = Modifier.weight(1f)) {
                Icon(if (running) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                Text(if (running) "توقف" else "شروع")
            }
            OutlinedButton(onClick = { running = false; seconds = mode * 60; completed = false }) { Icon(Icons.Default.Refresh, null); Text("بازنشانی") }
        }
        if (completed) Text(if (mode <= 10) "استراحت تمام شد؛ آماده‌ای؟" else "آفرین! جلسه مطالعه ثبت شد 🎉", color = MaterialTheme.colorScheme.primary)
        Text("چرخه پیشنهادی: ۲۵ دقیقه تمرکز و ۵ دقیقه استراحت.")
    }
}

@Composable
fun ReviewsScreen(reviews: List<StudyReview>, subjects: List<Subject>, onAdd: (String, String) -> Unit, onDone: (Long) -> Unit) {
    var show by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf(subjects.firstOrNull()?.name ?: "") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("مرور مطالب", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Button(onClick = { show = true }) { Icon(Icons.Default.Add, null); Text("مرور جدید") }
        }
        Spacer(Modifier.height(12.dp))
        if (reviews.isEmpty()) EmptyState("مروری در صف نداری. برای تثبیت یادگیری، یک مرور اضافه کن.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(reviews, key = { it.id }) { r ->
                Card { ListItem(
                    leadingContent = { Icon(Icons.Default.Replay, tint = MaterialTheme.colorScheme.primary) },
                    headlineContent = { Text(r.title) },
                    supportingContent = { Text("${r.subject} • ${SimpleDateFormat("yyyy/MM/dd", fa).format(Date(r.due))}") },
                    trailingContent = { IconButton(onClick = { onDone(r.id) }) { Icon(Icons.Default.CheckCircle, tint = MaterialTheme.colorScheme.secondary) } }
                ) }
            }
        }
    }
    if (show) AlertDialog(
        onDismissRequest = { show = false }, title = { Text("افزودن مرور") },
        text = { Column {
            OutlinedTextField(title, { title = it }, label = { Text("مطلب برای مرور") })
            Spacer(Modifier.height(8.dp))
            subjects.forEach { s -> Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = subject == s.name, onClick = { subject = s.name }); Text(s.name)
            } }
            Text("زمان مرور به‌صورت پیش‌فرض برای فردا تنظیم می‌شود.", style = MaterialTheme.typography.bodySmall)
        } },
        confirmButton = { TextButton(onClick = { if (title.isNotBlank()) { onAdd(title.trim(), subject); title = ""; show = false } }) { Text("ثبت") } },
        dismissButton = { TextButton(onClick = { show = false }) { Text("لغو") } }
    )
}

@Composable
fun EmptyState(message: String) {
    Box(Modifier.fillMaxWidth().padding(28.dp), contentAlignment = Alignment.Center) {
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
